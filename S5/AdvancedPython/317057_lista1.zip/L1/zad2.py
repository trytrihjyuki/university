
def is_palindrom(w):
    w = w.lower()                             # lowercase
    w = w.replace(' ', '')                    # no space
    w = ''.join(l for l in w if l.isalnum())  # no punctation
    return w == w[::-1]

print(is_palindrom('Ala, ma kotka.'))
print(is_palindrom("Eine güldne, gute Tugend: Lüge nie!"))