console.log('[+] zad3');
exports.x = 0;
let m_zad3 = require('./module.js');
console.log('module.x = ', m_zad3.x);
console.log('[-] zad3');
